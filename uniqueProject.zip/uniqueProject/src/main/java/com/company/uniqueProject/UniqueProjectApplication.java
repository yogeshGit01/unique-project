package com.company.uniqueProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniqueProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniqueProjectApplication.class, args);
	}

}
