package com.company.uniqueProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniqueProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
